import subprocess
import pandas as pd
import os
import time
import sys
from dotenv import load_dotenv
from pdf import  overall_summary_report
from operations import speed_calc, resolution_check, altitude_check, white_balance_check, getUnix, summary, write_parameters_to_file, convert_to_degree, check_angle
from operations import blur_detection
import concurrent.futures
import multiprocessing

load_dotenv()
log_file = os.environ['LOG']
out_file = os.environ['OUTPUT_FILE']
dataframes_to_merge = multiprocessing.Manager().list()  # Use Manager() to create a shared list


def analysis(csv_filename):
    df = pd.read_csv(csv_filename)
    if not df.empty:
        # UTC to Unix Time conversion
        df = getUnix(df)
        df['FloatGPSLatitude'] = df.apply(lambda row: convert_to_degree(row['GPSLatitude']), axis=1)
        df['FloatGPSLongitude'] = df.apply(lambda row: convert_to_degree(row['GPSLongitude']), axis=1)
        df['Speed'] = df.apply(lambda row: speed_calc(row['SpeedX'], row['SpeedY'], row['SpeedZ'])[0], axis=1)
        df['isSpeedWithinLimits'] = df.apply(lambda row: speed_calc(row['SpeedX'], row['SpeedY'], row['SpeedZ'])[1], axis=1)
        df['isMegaPixelGreaterThan12'] = df.apply(lambda row: resolution_check(row['Megapixels']), axis=1)
        df['isAltitudeWithinLimits'] = df.apply(lambda row: altitude_check(row['RelativeAltitude']), axis=1)
        df['Angle'] = df.apply(lambda row: check_angle(row['GimbalPitchDegree']), axis=1)
        df['isWhiteBalanceAuto'] = df.apply(lambda row: white_balance_check(row['WhiteBalance']), axis=1)
        with concurrent.futures.ProcessPoolExecutor(max_workers=4) as executor:
            image_paths = df['SourceFile'].tolist()
            blur_results = list(executor.map(blur_detection, image_paths))
        df['isImageClear'] = blur_results
        #df['isImageClear'] = df.apply(lambda row: blur_detection(row['SourceFile']), axis=1)
        boolean_columns = ['isSpeedWithinLimits', 'isMegaPixelGreaterThan12', 'isAltitudeWithinLimits', 'isWhiteBalanceAuto', 'Angle', 'isImageClear']
        df['QC Status'] = df[boolean_columns].all(axis=1).apply(lambda x: 'Passed' if x else 'Failed')

        summary_df = summary(df)
        # Displaying parameter values
        write_parameters_to_file(df, log_file)
        # Append the dataframe to the list
        dataframes_to_merge.append(df)
        # Create a writer to save data to an Excel file
        with pd.ExcelWriter(f"{os.path.dirname(csv_filename)}/analysis.xlsx") as writer:
            df.to_excel(writer, sheet_name='AnalysisOfMetadata', index=False)
            summary_df.to_excel(writer, sheet_name='Summary', index=False)
    else:
        write_parameters_to_file(f"ERR - No metadata found from the directory.", log_file)

# Function to process a folder
def process_folder(folder_path):
    csv_filename = os.path.join(folder_path,"metadata.csv")
    image_files = [os.path.join(folder_path, f) for f in os.listdir(folder_path) if f.lower().endswith(('.jpg', '.jpeg', '.JPG'))]

    if not image_files:
        write_parameters_to_file(f"DEB - No image files found in the {folder_path} folder.", log_file)
        return

    try:
        # Use ExifTool to extract metadata and save it as CSV
        subprocess.run(['exiftool', '-csv', '-r', '-ext', 'jpg', *image_files], stdout=open(csv_filename, 'w'), text=True, check=True)
        write_parameters_to_file(f"INF - Extraction metadata from: {folder_path} images", log_file)
        analysis(csv_filename)
        return csv_filename
    except subprocess.CalledProcessError as e:
        write_parameters_to_file(f"ERR - Error from exiftool during metadata extraction: {e.output}", log_file)
        return None

def parallel_process_folder(root_folder):
    # This function will be called concurrently to process different folders
    process_folder(root_folder)

# Main function to recursively process folders
def main(root_folder):
    with concurrent.futures.ProcessPoolExecutor(max_workers=4) as executor:
        folders = [root_folder] + [os.path.join(root_folder, d) for d in os.listdir(root_folder) if os.path.isdir(os.path.join(root_folder, d))]
        executor.map(parallel_process_folder, folders)


if __name__ == "__main__":     
        if len(sys.argv) != 2:
            write_parameters_to_file(f"ERR - Image Path is not Passed", log_file)
            write_parameters_to_file(f"INF - Usage: python3 <script.py> <path to the images>", log_file)
            sys.exit(1)
        try:
            root_path = sys.argv[1]
            if root_path :
                start_time = time.time()
                main(root_path)   
                # Merge all dataframes
                big_df = pd.concat(dataframes_to_merge, ignore_index=True)
                overall_summary_report(out_file, start_time, big_df)  # Pass the merged_df
                end_time = time.time()                  
                write_parameters_to_file(f"INF - Execution time: {end_time - start_time} seconds", log_file)
        except (ValueError, IndexError) as e:
            write_parameters_to_file(f"ERR - Please ensure the image path", log_file)    
            write_parameters_to_file(f"INF - Usage: python3 <script.py> <path to the images>", log_file)
